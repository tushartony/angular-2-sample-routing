import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nested-page4',
  templateUrl: './nested-page4.component.html',
  styleUrls: ['./nested-page4.component.css']
})
export class NestedPage4Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
