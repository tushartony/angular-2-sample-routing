import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nested-page1',
  templateUrl: './nested-page1.component.html',
  styleUrls: ['./nested-page1.component.css']
})
export class NestedPage1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
