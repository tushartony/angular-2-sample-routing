import { Component} from '@angular/core';

@Component({
       selector : 'company-list',
       template : '<h3>Company List Works</h3>'
})
export class CompanyListComponent{

}